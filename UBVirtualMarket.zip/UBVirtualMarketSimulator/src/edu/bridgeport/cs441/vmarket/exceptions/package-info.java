/**
 * 
 */
/**
 * @author Reza Basseda
 *
 */
package edu.bridgeport.cs441.vmarket.exceptions;