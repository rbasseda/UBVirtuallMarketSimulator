/**
 * 
 * This package implements the initialization classes and
 * shared resources.
 * 
 * @author Reza Basseda
 * @since 1.0
 * 
 *
 */
package edu.bridgeport.cs441.vmarket;