package edu.bridgeport.cs441.vmarket.parties;

/**
 * @author Reza Basseda
 *
 */

public class Person {

}
